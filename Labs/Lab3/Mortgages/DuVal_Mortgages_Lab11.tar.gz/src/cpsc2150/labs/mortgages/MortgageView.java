package cpsc2150.labs.mortgages;

import java.util.Scanner;

public class MortgageView {

    Scanner input = new Scanner(System.in);

    //Constructor
    MortgageView() {
    }

    double getHouseCost() {
        printToUser("How much does the house cost?");
        double house_C = input.nextInt();
        return (house_C);
    }

    double getMonthlyPayment() {
        printToUser("How much is the down payment?");
        double monthly_P = input.nextInt();
        return (monthly_P);
    }

    int getYears() {
        printToUser("How many years?");
        int years = input.nextInt();
        return (years);
    }

    double getMonthlyDebt() {
        printToUser("How much are your monthly debt payments?");
        double monthly_D = input.nextInt();
        return (monthly_D);
    }

    double getYearlyIncome() {
        printToUser("How much is your yearly income?");
        double yearly_I = input.nextInt();
        return (yearly_I);
    }

    int getCreditScore() {
        printToUser("What is your credit score?");
        int credit_S = input.nextInt();
        return (credit_S);
    }

    String getName() {
        String name = "";
        if (name.isEmpty()) {
            this.printToUser("What's your name?");
            name = input.next();
        }
        return name;
    }

    void printToUser(String message) {
        System.out.println(message);
    }

    boolean getAnotherMortgage() {
        Character Y = 'Y', N = 'N', another_M = 'M';
        while ((!another_M.equals(Y)) && (!another_M.equals(N))) {

            this.printToUser("Would you like to apply for another mortgage? Y/N");
            another_M = input.next().charAt(0);

            if ((!another_M.equals(Y)) && (!another_M.equals(N))) {
                this.printToUser("Please enter 'Y' or 'N'.");
            }
        }

        return (another_M.equals(Y));
    }

    boolean getAnotherCustomer() {
        Character Y = 'Y', N = 'N', another_C = 'M';
        while ((!another_C.equals(Y)) && (!another_C.equals(N))) {

            this.printToUser("Would you like to consider another customer? Y/N");
            another_C = input.next().charAt(0);

            if ((!another_C.equals(Y)) && (!another_C.equals(N))) {
                this.printToUser("Please enter 'Y' or 'N'.");
            }
        }

        return (another_C.equals(Y));
    }

}
