package cpsc2150.labs.mortgages;


public class MortgageController {

    private MortgageView v;
    private double house_C, monthly_P, monthly_D, yearly_I;
    private int years, credit_S;
    private String name;
    private int MAX_CREDIT = 850;


    MortgageController(MortgageView view) {
       v = view;
    }

    void run() {

        boolean another_M = true, another_C = true;

        while (another_M || another_C) {

            if (another_C) {

                name = v.getName();
                while (name.isEmpty()) {
                    v.printToUser("Please enter your name.");
                    name = v.getName();
                }

                yearly_I = v.getYearlyIncome();
                while (yearly_I <= 0.0) {
                    v.printToUser("Income must be greater than or equal to 0.");
                    yearly_I = v.getYearlyIncome();
                }

                monthly_D = v.getMonthlyDebt();
                while (monthly_D < 0.0) {
                    v.printToUser("Debt must be greater than or equal to 0.");
                    monthly_D = v.getMonthlyDebt();
                }

                credit_S = v.getCreditScore();
                while ((credit_S <= 0) || (credit_S >= MAX_CREDIT)) {
                    v.printToUser("Credit Score must be greater than 0 and less than 850.");
                    credit_S = v.getCreditScore();
                }
            }

            if (another_M) {
                house_C = v.getHouseCost();
                while (house_C <= 0.0) {
                    v.printToUser("Cost must be greater than 0.");
                    house_C = v.getHouseCost();
                }

                monthly_P = v.getMonthlyPayment();
                while ((monthly_P <= 0) || (monthly_P > house_C)) {
                    v.printToUser("Down payment must be greater than 0 and less than the cost of the house.");
                    monthly_P = v.getMonthlyPayment();
                }

                years = v.getYears();
                while (years <= 0) {
                    v.printToUser("Years must be greater than 0.");
                    years = v.getYears();
                }
            }


            Customer customer = new Customer(monthly_D, yearly_I, credit_S, name);
            Mortgage mortgage = new Mortgage(house_C, monthly_P, years, customer);

            v.printToUser(customer.toString());
            v.printToUser(mortgage.toString());

            another_M = v.getAnotherMortgage();
            another_C = v.getAnotherCustomer();

        }
    }

}
